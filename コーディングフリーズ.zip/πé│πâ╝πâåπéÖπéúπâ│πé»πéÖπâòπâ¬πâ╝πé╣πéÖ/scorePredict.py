import csv
import sys
from sklearn.svm import LinearSVC
from sklearn import svm
import numpy as np
import copy
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV
from sklearn.kernel_ridge import KernelRidge
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.linear_model import Ridge


args = sys.argv

def regression_main():
     # model = svm.SVR(kernel='rbf', C=1e3, gamma=0.1)
      in_data = []
      label_data = []
      with open(args[1],"r",encoding="utf-8") as csv_file:
        first_row = True
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
          if (first_row == False):
            in_data.append([float(row[0])])
            label_data.append(float(row[8]))
          first_row = False

      print(in_data,label_data)

      tuned_parameters = [
        {'kernel': ['rbf'], 'gamma': [10**i for i in range(-4,5)], 'C': [10**i for i in range(-3, 8)]}#,
     #   {'kernel': ['linear'], 'C': [1, 10, 100, 1000]}
      ]

      model = GridSearchCV(svm.SVR(), tuned_parameters, cv=5)

      model.fit(in_data,label_data)


      plt.scatter([e[0] for e in in_data], [e for e in label_data])
      plt.plot([e[0] for e in in_data], model.predict(in_data))
      plt.show()

      while True:
          user_input=input("end?>")
          if user_input=="end":break
          user_in_data=[]
          for i in range(len(in_data[0])):
               t=float(input(">"))
               user_in_data.append(t)

          print(model.predict([user_in_data])[0])



def main():
     print("1:label\n2:回帰")
     n=int(input(">"))     
     
     if n==2:
         regression_main()

main()